## Telecom operators

Add support for unsupported operators so that Volte is already in normal use with NR

## Changelog
<br>https://github.com/ender-zhao/Pixel-5-operator-network-unlock
<br> by Ender Zhao CLUB

## Donate

<br>https://github.com/ender-zhao/EZc

## ---------------------------------------

以上是原模块作者信息，感谢他的模块，我进行了一些修改让Pixel4A能得到一些自己想用的功能:
1.为Pixel4A增加中国移动,中国联通,中国电信Volte支持